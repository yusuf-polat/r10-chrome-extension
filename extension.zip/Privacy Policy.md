# R10 Bildirim Asistanı Gizlilik Politikası

## Toplanan Veriler
- R10.net güvenlik token'ı
- Bildirim içerikleri
- Özel mesaj başlıkları
- Arkadaşlık istekleri

## Veri Kullanımı
- Veriler sadece bildirim gösterimi için kullanılır
- Hiçbir veri üçüncü taraflarla paylaşılmaz
- Tüm veriler yerel olarak saklanır
- Veriler sadece eklentinin çalışması için gerekli süre boyunca tutulur

## Veri Güvenliği
- Tüm veriler şifrelenmiş olarak saklanır
- Veriler sadece kullanıcının tarayıcısında tutulur
- Hiçbir veri harici sunuculara gönderilmez

## İletişim
[İletişim bilgileriniz]

Son güncelleme: 14.05.2025